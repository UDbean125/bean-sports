Hennigan's Huddle - in-page player for hen-solutions.com
=========================================================

Files
  apply-huddle.py       one command that applies everything (safe to re-run, makes backups)
  huddle-section.html   the new section (inserted before the About section)
  huddle-player.js      the player (reads the show's RSS feed, plays episodes)
  huddle-cover.jpg      200px cover thumbnail (9 KB instead of the 862 KB original)

SITE=/Volumes/Satechi/HenSolutions/hen-solutions-site-src

1) Confirm that folder matches the live site (expect: MATCHES LIVE):
     cd "$SITE" && diff <(curl -s https://hen-solutions.com/) index.html && echo MATCHES LIVE

2) Apply the changes (backups go to ../hen-solutions-site-huddle-backups/):
     python3 ~/Downloads/hen-solutions-huddle/apply-huddle.py "$SITE"

3) Deploy the WHOLE folder to Cloudflare Pages (a direct upload replaces the entire site):
     cd "$SITE" && npx wrangler pages deploy . --project-name hen-solutions-site --branch main

4) Check it's live:
     curl -s https://hen-solutions.com/ | grep -c 'id="huddle"'     (expect 1)
     curl -sI https://hen-solutions.com/huddle-player.js | head -1  (expect 200)

If step 3 reports a "Preview" deployment instead of Production, re-run it with the
production branch name shown in the Cloudflare dashboard (Workers & Pages > hen-solutions-site).
To undo: copy index.html and hen-search.js back from ../hen-solutions-site-huddle-backups/,
delete huddle-player.js and huddle-cover.jpg from the site folder, and redeploy.
