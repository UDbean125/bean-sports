/**
 * Hen Solutions — Hennigan's Huddle in-page player
 * Zero-dependency. Reads the show's public RSS feed, plays the newest episode
 * with a native <audio> element, and lists recent episodes.
 * Safe DOM building only (textContent), no innerHTML with feed data.
 */
(function () {
  'use strict';

  var root = document.getElementById('huddle-player');
  if (!root) return;

  var FEEDS = ['/api/feed.xml', 'https://podcast.hhsolutions.cloud/api/feed.xml'];
  var APPLE_URL = 'https://podcasts.apple.com/us/podcast/hennigans-huddle/id1896591291';
  var SHOW = "Hennigan's Huddle";
  var INITIAL = 6;
  var THUMB = '/huddle-cover.jpg';

  var episodes = [];
  var cover = '';
  var current = -1;
  var showAll = false;
  var ui = {};

  /* ---------- tiny DOM helper ---------- */
  function el(tag, attrs, kids) {
    var n = document.createElement(tag);
    Object.keys(attrs || {}).forEach(function (k) {
      if (k === 'text') n.textContent = attrs[k];
      else if (k === 'class') n.className = attrs[k];
      else n.setAttribute(k, attrs[k]);
    });
    (kids || []).forEach(function (c) { if (c) n.appendChild(c); });
    return n;
  }

  /* ---------- feed parsing ---------- */
  function text(node, tag) {
    var e = node.getElementsByTagName(tag)[0];
    return e ? e.textContent.trim() : '';
  }
  function parseDuration(s) {
    if (!s) return 0;
    if (s.indexOf(':') === -1) return parseInt(s, 10) || 0;
    return s.split(':').reduce(function (acc, p) { return acc * 60 + (parseInt(p, 10) || 0); }, 0);
  }
  function firstParagraph(s) {
    var p = (s || '').split(/\n\s*\n/)[0] || '';
    return p.replace(/\s+/g, ' ').trim();
  }
  function parseFeed(xml) {
    var doc = new DOMParser().parseFromString(xml, 'application/xml');
    if (doc.getElementsByTagName('parsererror').length) throw new Error('bad feed');
    var img = doc.getElementsByTagName('itunes:image')[0];
    cover = img ? (img.getAttribute('href') || '') : '';
    var out = [];
    var items = doc.getElementsByTagName('item');
    for (var i = 0; i < items.length; i++) {
      var it = items[i];
      var enc = it.getElementsByTagName('enclosure')[0];
      var url = enc && enc.getAttribute('url');
      if (!url || url.indexOf('https://') !== 0) continue;
      out.push({
        title: text(it, 'title'),
        desc: firstParagraph(text(it, 'description')),
        date: Date.parse(text(it, 'pubDate')) || 0,
        secs: parseDuration(text(it, 'itunes:duration')),
        url: url
      });
    }
    out.sort(function (a, b) { return b.date - a.date; });
    return out;
  }
  function fetchText(url, ms) {
    var ctl = window.AbortController ? new AbortController() : null;
    var timer = ctl ? setTimeout(function () { ctl.abort(); }, ms) : null;
    return fetch(url, { cache: 'no-cache', signal: ctl ? ctl.signal : undefined }).then(function (r) {
      clearTimeout(timer);
      if (!r.ok) throw new Error('HTTP ' + r.status);
      return r.text();
    }, function (err) { clearTimeout(timer); throw err; });
  }
  function loadFeed(i) {
    if (i >= FEEDS.length) return Promise.reject(new Error('no feed'));
    return fetchText(FEEDS[i], 10000).then(parseFeed).then(function (list) {
      if (!list.length) throw new Error('empty feed');
      return list;
    }).catch(function () { return loadFeed(i + 1); });
  }

  /* ---------- formatting ---------- */
  function fmtDate(ms) {
    if (!ms) return '';
    try { return new Date(ms).toLocaleDateString('en-US', { weekday: 'short', month: 'short', day: 'numeric', timeZone: 'America/New_York' }); }
    catch (e) { return ''; }
  }
  function fmtDur(s) { var m = Math.round(s / 60); return m > 0 ? m + ' min' : ''; }
  function meta(e) { return [fmtDate(e.date), fmtDur(e.secs)].filter(Boolean).join(' · '); }

  /* ---------- render ---------- */
  function build() {
    root.textContent = '';
    ui.cover = el('img', { class: 'hq-cover', src: THUMB, alt: SHOW + ' cover art', width: '96', height: '96', decoding: 'async' });
    // Small local thumbnail first; if it isn't deployed, fall back to the feed's (large) cover.
    ui.cover.addEventListener('error', function () {
      if (cover && ui.cover.getAttribute('src') !== cover) ui.cover.setAttribute('src', cover); else ui.cover.style.display = 'none';
    });
    ui.label = el('span', { class: 'hq-label' });
    ui.title = el('h3', { class: 'hq-title' });
    ui.meta = el('span', { class: 'hq-meta' });
    ui.desc = el('p', { class: 'hq-desc' });
    ui.audio = el('audio', { class: 'hq-audio', controls: '', preload: 'none' });
    ui.back = el('button', { type: 'button', class: 'hq-skip', text: '↺ 15s', 'aria-label': 'Back 15 seconds' });
    ui.fwd = el('button', { type: 'button', class: 'hq-skip', text: '30s ↻', 'aria-label': 'Forward 30 seconds' });
    ui.status = el('p', { class: 'hq-status', role: 'status' });
    ui.list = el('ul', { class: 'hq-list' });
    ui.more = el('button', { type: 'button', class: 'hq-more', hidden: '' });

    var head = el('div', { class: 'hq-head' }, [
      ui.cover,
      el('div', { class: 'hq-headtext' }, [ui.label, ui.title, ui.meta])
    ]);
    root.appendChild(el('div', { class: 'hq-now' }, [
      head, ui.desc, ui.audio,
      el('div', { class: 'hq-skips' }, [ui.back, ui.fwd]),
      ui.status
    ]));
    root.appendChild(ui.list);
    root.appendChild(ui.more);

    ui.back.addEventListener('click', function () { ui.audio.currentTime = Math.max(0, ui.audio.currentTime - 15); });
    ui.fwd.addEventListener('click', function () { ui.audio.currentTime = ui.audio.currentTime + 30; });
    ui.audio.addEventListener('error', function () { if (ui.audio.getAttribute('src')) showError(); });
    ui.more.addEventListener('click', function () { showAll = true; renderList(); });
    ui.list.addEventListener('click', function (e) {
      var b = e.target.closest ? e.target.closest('[data-ep]') : null;
      if (b) select(parseInt(b.getAttribute('data-ep'), 10), true);
    });
  }

  function showError() {
    ui.status.textContent = "This episode couldn't play here. ";
    ui.status.appendChild(el('a', { href: APPLE_URL, target: '_blank', rel: 'noopener noreferrer', text: 'Open it in Apple Podcasts ↗' }));
  }

  function renderList() {
    var shown = showAll ? episodes : episodes.slice(0, INITIAL);
    ui.list.textContent = '';
    ui.list.classList.toggle('is-scroll', showAll);
    shown.forEach(function (e, i) {
      var b = el('button', { type: 'button', class: 'hq-ep' + (i === current ? ' is-active' : ''), 'data-ep': String(i) }, [
        el('span', { class: 'hq-epplay', 'aria-hidden': 'true', text: '▶' }),
        el('span', { class: 'hq-eptext' }, [
          el('span', { class: 'hq-eptitle', text: e.title }),
          el('span', { class: 'hq-epmeta', text: meta(e) })
        ])
      ]);
      if (i === current) b.setAttribute('aria-current', 'true');
      ui.list.appendChild(el('li', {}, [b]));
    });
    var hide = showAll || episodes.length <= INITIAL;
    if (hide) ui.more.setAttribute('hidden', ''); else ui.more.removeAttribute('hidden');
    ui.more.textContent = 'Show all ' + episodes.length + ' episodes';
  }

  function select(i, play) {
    var e = episodes[i];
    if (!e) return;
    current = i;
    ui.status.textContent = '';
    ui.label.textContent = i === 0 ? 'Latest episode' : 'Now selected';
    ui.title.textContent = e.title;
    ui.meta.textContent = meta(e);
    ui.desc.textContent = e.desc;
    ui.audio.src = e.url;
    if (play) {
      var pr = ui.audio.play();
      if (pr && pr.catch) pr.catch(function (err) { if (!err || err.name !== 'AbortError') showError(); });
    }
    renderList();
    try {
      if ('mediaSession' in navigator && window.MediaMetadata) {
        navigator.mediaSession.metadata = new MediaMetadata({
          title: e.title, artist: 'Bryan Hennigan', album: SHOW,
          artwork: cover ? [{ src: cover, sizes: '1400x1400', type: 'image/jpeg' }] : []
        });
        navigator.mediaSession.setActionHandler('seekbackward', function () { ui.audio.currentTime = Math.max(0, ui.audio.currentTime - 15); });
        navigator.mediaSession.setActionHandler('seekforward', function () { ui.audio.currentTime = ui.audio.currentTime + 30; });
      }
    } catch (err) { /* media session is optional */ }
  }

  function fallback() {
    root.textContent = '';
    root.appendChild(el('div', { class: 'hq-now' }, [
      el('p', { class: 'hq-desc', text: "The episode list couldn't load right now. You can still listen on Apple Podcasts." }),
      el('a', { class: 'hq-btn hq-btn-light', href: APPLE_URL, target: '_blank', rel: 'noopener noreferrer', text: 'Open in Apple Podcasts ↗' })
    ]));
  }

  /* ---------- start when the section nears the viewport ---------- */
  var started = false;
  function start() {
    if (started) return;
    started = true;
    loadFeed(0).then(function (list) {
      episodes = list;
      build();
      select(0, false);
    }).catch(fallback);
  }
  if ('IntersectionObserver' in window) {
    var io = new IntersectionObserver(function (entries) {
      if (entries.some(function (x) { return x.isIntersecting; })) { io.disconnect(); start(); }
    }, { rootMargin: '600px 0px' });
    io.observe(root);
  } else {
    start();
  }
})();
