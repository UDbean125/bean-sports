#!/usr/bin/env python3
"""
Adds the Hennigan's Huddle in-page player to the Hen Solutions site folder.

Usage:   python3 apply-huddle.py /path/to/hen-solutions-site

What it does (safe to run more than once):
  1. index.html     -> inserts the #huddle section before <!-- ABOUT SECTION -->
                       and a <script src="/huddle-player.js" defer> tag
  2. hen-search.js  -> adds the "huddle" icon/colour/label entries (3 lines)
  3. copies huddle-player.js and huddle-cover.jpg into the site folder
Every file it edits is first backed up into ../hen-solutions-site-huddle-backups/ (outside the site folder).
"""
import os
import re
import shutil
import sys

HERE = os.path.dirname(os.path.abspath(__file__))


def read(path):
    with open(path, encoding="utf-8") as f:
        return f.read()


def write(path, text):
    with open(path, "w", encoding="utf-8") as f:
        f.write(text)


def backup(path):
    # Backups go in a sibling folder so a Pages deploy of the site folder never publishes them.
    bdir = os.path.join(os.path.dirname(os.path.dirname(path)), "hen-solutions-site-huddle-backups")
    os.makedirs(bdir, exist_ok=True)
    bak = os.path.join(bdir, os.path.basename(path))
    if not os.path.exists(bak):
        shutil.copy2(path, bak)


def fail(msg):
    print("ERROR: " + msg)
    sys.exit(1)


def main():
    if len(sys.argv) != 2:
        fail("usage: python3 apply-huddle.py /path/to/hen-solutions-site")
    site = os.path.abspath(sys.argv[1])
    index_path = os.path.join(site, "index.html")
    search_path = os.path.join(site, "hen-search.js")
    if not os.path.isfile(index_path):
        fail("no index.html in " + site + " (is this the site folder?)")
    for needed in ("huddle-section.html", "huddle-player.js", "huddle-cover.jpg"):
        if not os.path.isfile(os.path.join(HERE, needed)):
            fail("missing " + needed + " next to this script")

    changed = []
    html = read(index_path)

    # 1a. section
    if 'id="huddle"' in html:
        print("index.html: #huddle section already present - skipping")
    else:
        section = read(os.path.join(HERE, "huddle-section.html"))
        marker = "    <!-- ABOUT SECTION -->"
        if marker in html:
            html = html.replace(marker, section + marker, 1)
        else:
            m = re.search(r'^[ \t]*<section id="about"', html, flags=re.M)
            if not m:
                fail('could not find the About section ("<!-- ABOUT SECTION -->" or <section id="about">) in index.html')
            html = html[: m.start()] + section + html[m.start():]
        changed.append("index.html (section)")

    # 1b. script tag
    if "/huddle-player.js" in html:
        print("index.html: player script tag already present - skipping")
    else:
        tag = '  <script src="/huddle-player.js" defer></script>\n'
        m = re.search(r'<script src="/hen-search\.js"></script>\n', html)
        if m:
            html = html[: m.end()] + tag + html[m.end():]
        elif "</body>" in html:
            html = html.replace("</body>", tag + "</body>", 1)
        else:
            fail("could not find where to add the script tag")
        changed.append("index.html (script tag)")

    if any(c.startswith("index.html") for c in changed):
        backup(index_path)
        write(index_path, html)

    # 2. search overlay entries
    if os.path.isfile(search_path):
        js = read(search_path)
        if re.search(r"\bhuddle\s*:", js):
            print("hen-search.js: huddle entries already present - skipping")
        else:
            adds = [
                (r"([ \t]*)harbour:\s*'[^']*',?\n", "huddle: '\U0001F399️',"),
                (r"([ \t]*)harbour:\s*'#[0-9A-Fa-f]{3,8}',?\n", "huddle: '#E8573A',"),
                (r"([ \t]*)harbour:\s*'Harbour',?\n", 'huddle: "Hennigan\'s Huddle",'),
            ]
            done = 0
            for pat, line in adds:
                m = re.search(pat, js)
                if m:
                    js = js[: m.end()] + m.group(1) + line + "\n" + js[m.end():]
                    done += 1
            if done == 3:
                backup(search_path)
                write(search_path, js)
                changed.append("hen-search.js")
            else:
                print("WARNING: hen-search.js looks different from expected; skipped it. "
                      "The Huddle section still works, but site search may label it 'undefined'.")
    else:
        print("note: no hen-search.js in the folder - skipping search entries")

    # 3. assets
    for name in ("huddle-player.js", "huddle-cover.jpg"):
        dest = os.path.join(site, name)
        shutil.copy2(os.path.join(HERE, name), dest)
        changed.append(name)

    print("\nDone. Updated: " + ", ".join(changed))
    print("\nNext, deploy the folder to Cloudflare Pages:")
    print("  cd " + site)
    print("  npx wrangler pages deploy . --project-name hen-solutions-site --branch main")


if __name__ == "__main__":
    main()
